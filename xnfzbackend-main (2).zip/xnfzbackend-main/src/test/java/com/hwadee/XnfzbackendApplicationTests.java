package com.hwadee;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class XnfzbackendApplicationTests {

    @Test
    void contextLoads() {
    }

}
