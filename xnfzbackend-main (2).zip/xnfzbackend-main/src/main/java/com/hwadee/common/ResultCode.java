package com.hwadee.common;

public interface ResultCode {
    /**
     * 成功
     */
    Integer SUCCESS = 200;
    /**
     * 失败
     */
    Integer ERROR = 500;
}
