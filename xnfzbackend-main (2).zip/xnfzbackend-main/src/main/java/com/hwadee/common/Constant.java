package com.hwadee.common;

public class Constant {
    public static final String USER_STUDENT = "1";
    public static final String USER_TEACHER = "2";
}
