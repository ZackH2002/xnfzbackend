package com.hwadee.mapper;


import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.hwadee.entity.Laboratory;
import com.hwadee.entity.SimulationEquipment;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface LaboratoryMapper extends BaseMapper<Laboratory> {
    List<Laboratory> listLaboratory();
}
